<script>
{
  var popup = document.getElementById("myPopup");
  popup.classList.toggle("show");
}
</script>
